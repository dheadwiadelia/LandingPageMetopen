# ==============================================================================
# AI-15: INTERACTIVE CLUSTERING TOOLKIT (GUI VERSION)
# Platform: VS Code / Local Python
# ==============================================================================

import pandas as pd
import numpy as np
import datetime as dt
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
import warnings
import sys
import os

# Library untuk GUI File Picker
import tkinter as tk
from tkinter import filedialog

# Konfigurasi Tampilan
warnings.filterwarnings('ignore')
sns.set(style="whitegrid", context="notebook")

# --- ASCII ART HEADER (Agar terlihat profesional di Terminal) ---
def print_header():
    print(r"""
    ==========================================================
      ___   ___      ___  _             _               _   
     / _ \ |_ _|    / __|| | _  _  ___ | |_  ___  _ _  (_) _ _  __ _ 
    |  _  | | |    | (__ | || || |(_-< |  _|/ -_)| '_| | || ' \/ _` |
     \_|_/ |___|    \___||_| \_,_|/__/  \__|\___||_|   |_||_||_\__, |
                                                               |___/ 
             UNIVERSAL SEGMENTATION TOOLKIT v3.0
    ==========================================================
    """)

# --- FUNGSI MEMINTA INPUT FILE (GUI) ---
def get_user_file():
    print("\n[SYSTEM] Menunggu input user...")
    print("[SYSTEM] Silakan pilih file CSV melalui jendela pop-up...")
    
    # Membuat jendela Tkinter tersembunyi
    root = tk.Tk()
    root.withdraw() # Sembunyikan window utama
    root.wm_attributes('-topmost', 1) # Paksa pop-up ke depan layar

    # Buka File Dialog
    file_path = filedialog.askopenfilename(
        title="Pilih Dataset (CSV)",
        filetypes=[("CSV Files", "*.csv"), ("All Files", "*.*")]
    )
    
    if file_path:
        print(f"[USER] File dipilih: {os.path.basename(file_path)}")
        return file_path
    else:
        print("[SYSTEM] Tidak ada file yang dipilih. Keluar...")
        return None

# --- CLASS TOOLKIT UTAMA (LOGIKA SAMA SEPERTI SEBELUMNYA) ---
class UniversalToolkit:
    def __init__(self, filepath):
        self.filepath = filepath
        self.filename = os.path.basename(filepath)
        self.data_raw = None
        self.data_processed = None 
        self.data_original_values = None
        self.mode = "UNKNOWN"
        
    def load_and_adapt(self):
        print(f"\n>>> SEDANG MEMUAT: {self.filename}")
        try:
            df = pd.read_csv(self.filepath, encoding='ISO-8859-1')
        except:
            df = pd.read_csv(self.filepath)
            
        # AUTO-ADAPTER
        cols = [str(c).lower() for c in df.columns]
        
        # Skenario A: Retail Sales
        if 'transaction id' in cols or 'transaction_id' in cols:
            print("    [DETECTED] Format Retail Sales Dataset")
            mapper = {'Transaction ID': 'InvoiceNo', 'Date': 'InvoiceDate', 'Customer ID': 'CustomerID', 
                      'Total Amount': 'TotalPrice', 'Price per Unit': 'UnitPrice', 'Product Category': 'Category'}
            df.rename(columns={k: v for k, v in mapper.items() if k in df.columns}, inplace=True)
            
        # Skenario B: Customer Shopping
        elif 'invoice_no' in cols:
            print("    [DETECTED] Format Customer Shopping Data")
            mapper = {'invoice_no': 'InvoiceNo', 'invoice_date': 'InvoiceDate', 'customer_id': 'CustomerID', 
                      'price': 'UnitPrice', 'quantity': 'Quantity'}
            df.rename(columns={k: v for k, v in mapper.items() if k in df.columns}, inplace=True)
            
        # Skenario C: Marketing
        elif 'ad group' in cols or 'campaign' in cols:
            print("    [DETECTED] Data Marketing/Ads")
            self.mode = "MARKETING"
            if 'Ad Group' in df.columns: df['Ref_ID'] = df['Ad Group']
            else: df['Ref_ID'] = df.index

        self.data_raw = df
        return df

    def preprocess(self):
        df = self.data_raw.copy()
        print(">>> MELAKUKAN PREPROCESSING...")
        
        if 'InvoiceDate' in df.columns:
            self.mode = "TRANSACTION (RFM)"
            print("    [MODE] Analisis RFM (Recency, Frequency, Monetary)")
            df['InvoiceDate'] = pd.to_datetime(df['InvoiceDate'], dayfirst=True, format='mixed', errors='coerce')
            df = df.dropna(subset=['InvoiceDate'])
            
            if 'TotalPrice' not in df.columns:
                if 'Quantity' in df.columns and 'UnitPrice' in df.columns:
                    df['TotalPrice'] = df['Quantity'] * df['UnitPrice']
                else:
                    print("    [ERROR] Kolom tidak lengkap untuk RFM.")
                    return False

            latest_date = df['InvoiceDate'].max() + dt.timedelta(days=1)
            rfm = df.groupby('CustomerID').agg({
                'InvoiceDate': lambda x: (latest_date - x.max()).days,
                'InvoiceNo': 'count',
                'TotalPrice': 'sum'
            })
            rfm.rename(columns={'InvoiceDate': 'Recency', 'InvoiceNo': 'Frequency', 'TotalPrice': 'Monetary'}, inplace=True)
            self.data_original_values = rfm.copy()
            self.data_processed = rfm
            
        elif self.mode == "MARKETING":
            print("    [MODE] Analisis Performa Iklan")
            metrics = ['Impressions', 'Clicks', 'Cost', 'Revenue', 'Conversions']
            self.data_original_values = df.set_index('Ref_ID')[[c for c in metrics if c in df.columns]].fillna(0)
            self.data_processed = self.data_original_values.copy()
            
        else:
            print("    [MODE] Generic Profiling (Non-RFM)")
            self.data_original_values = df.select_dtypes(include=[np.number]).fillna(0)
            self.data_processed = self.data_original_values.copy()
            
        return True

    def run_clustering(self, k=3):
        print(f">>> MENJALANKAN K-MEANS (k={k})...")
        scaler = StandardScaler()
        data_scaled = scaler.fit_transform(self.data_processed)
        
        kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = kmeans.fit_predict(data_scaled)
        self.data_original_values['Cluster_Label'] = labels
        
        # Auto-Labeling
        self._assign_labels()
        
        try:
            score = silhouette_score(data_scaled, labels)
            print(f"    [RESULT] Silhouette Score: {score:.3f} (Validitas Cluster)")
        except: pass

    def _assign_labels(self):
        df = self.data_original_values
        if "Monetary" in df.columns:
            means = df.groupby('Cluster_Label')['Monetary'].mean().sort_values(ascending=False)
            names = ['Platinum (VIP)', 'Gold (Loyal)', 'Silver (Standard)', 'Bronze (Low)']
            label_map = {cluster_id: names[i] if i < len(names) else f'Segmen {i}' for i, cluster_id in enumerate(means.index)}
            df['Segment_Name'] = df['Cluster_Label'].map(label_map)
        elif "Revenue" in df.columns or "Clicks" in df.columns:
            target = 'Revenue' if 'Revenue' in df.columns else 'Clicks'
            means = df.groupby('Cluster_Label')[target].mean().sort_values(ascending=False)
            names = ['Winning Ads (Top)', 'Potential', 'Underperforming']
            label_map = {cluster_id: names[i] if i < len(names) else f'Cluster {i}' for i, cluster_id in enumerate(means.index)}
            df['Segment_Name'] = df['Cluster_Label'].map(label_map)
        else:
            df['Segment_Name'] = "Cluster " + df['Cluster_Label'].astype(str)

    def visualize(self):
        print(">>> MEMBUKA VISUALISASI...")
        df = self.data_original_values
        
        # Tentukan sumbu
        if "Recency" in df.columns: x, y, title = 'Recency', 'Monetary', "Customer Segmentation (RFM)"
        elif "Cost" in df.columns: x, y, title = 'Cost', 'Revenue' if 'Revenue' in df.columns else 'Clicks', "Ad Performance"
        else: cols = df.select_dtypes(include=[np.number]).columns; x, y, title = cols[0], cols[1], "Clustering Map"
            
        plt.figure(figsize=(10, 6))
        sns.scatterplot(data=df, x=x, y=y, hue='Segment_Name', palette='viridis', s=100, alpha=0.8)
        plt.title(f"{title} - {self.filename}")
        if y in ['Monetary', 'Revenue']: plt.yscale('log')
        plt.ylabel(y); plt.xlabel(x)
        plt.legend(bbox_to_anchor=(1.05, 1), loc='upper left')
        plt.tight_layout()
        
        print("    [INFO] Grafik telah dibuka di jendela baru.")
        plt.show()
        
        # Save
        out_name = f"RESULT_{self.filename}"
        df.to_csv(out_name)
        print(f"\n[SUKSES] Hasil analisis tersimpan di: {out_name}")
        print("\n--- RINGKASAN PROFIL ---")
        display_cols = df.select_dtypes(include=[np.number]).columns.tolist()
        if 'Cluster_Label' in display_cols: display_cols.remove('Cluster_Label')
        print(df.groupby('Segment_Name')[display_cols].mean().round(2))

# ==============================================================================
# MAIN EXECUTION LOOP
# ==============================================================================
if __name__ == "__main__":
    while True:
        print_header()
        
        # 1. Minta File
        print("Apakah Anda ingin memulai analisis?")
        choice = input("Ketik 'y' untuk pilih file, atau 'x' untuk keluar: ").lower()
        
        if choice == 'x':
            print("Terima kasih telah menggunakan toolkit ini. Bye!")
            break
        
        if choice == 'y':
            csv_file = get_user_file()
            
            if csv_file:
                # 2. Jalankan Toolkit
                app = UniversalToolkit(csv_file)
                app.load_and_adapt()
                if app.preprocess():
                    app.run_clustering(k=3)
                    app.visualize()
                    input("\nTekan Enter untuk kembali ke menu utama...")
                else:
                    print("Gagal memproses file.")
            else:
                input("\nPembatalan file. Tekan Enter...")
                
        # Bersihkan layar (Opsional, agar rapi)
        os.system('cls' if os.name == 'nt' else 'clear')